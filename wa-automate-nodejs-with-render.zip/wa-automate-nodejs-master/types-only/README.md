# @open-wa/wa-automate-types-only

You are most likely looking for [@open-wa/wa-automate](https://www.npmjs.com/package/@open-wa/wa-automate). This package is identical to [@open-wa/wa-automate](https://www.npmjs.com/package/@open-wa/wa-automate) but only contains it's types.
