# structures/MessageCollector

## Index

### Classes

- [MessageCollector](/reference/structures/MessageCollector/classes/MessageCollector.md)
