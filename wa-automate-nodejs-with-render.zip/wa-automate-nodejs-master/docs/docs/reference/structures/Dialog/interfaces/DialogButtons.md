# Interface: DialogButtons

## Properties

### label

> **label**: `string`

***

### value

> **value**: `string`
