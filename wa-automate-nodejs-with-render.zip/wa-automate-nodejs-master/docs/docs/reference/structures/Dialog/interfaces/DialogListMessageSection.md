# Interface: DialogListMessageSection

## Properties

### rows

> **rows**: [`DialogListMessageRow`](/reference/structures/Dialog/interfaces/DialogListMessageRow.md)[]

***

### title

> **title**: `string`
