# Interface: CurrentDialogProps

## Indexable

 \[`k`: `string`\]: `any`
