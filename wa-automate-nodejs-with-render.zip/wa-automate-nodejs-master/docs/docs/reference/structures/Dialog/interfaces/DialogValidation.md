# Interface: DialogValidation

## Properties

### errorMessage

> **errorMessage**: `string`

***

### type

> **type**: [`ValidationType`](/reference/structures/Dialog/enumerations/ValidationType.md)

***

### value

> **value**: `string` \| [`CheckFunction`](/reference/structures/Dialog/type-aliases/CheckFunction.md)
