# Interface: DialogListMessageRow

## Properties

### description

> **description**: `string`

***

### title

> **title**: `string`

***

### value

> **value**: `string`
