# Enumeration: ValidationType

## Enumeration Members

### CHECK

> **CHECK**: `"check"`

***

### LENGTH

> **LENGTH**: `"length"`

***

### REGEX

> **REGEX**: `"regex"`
