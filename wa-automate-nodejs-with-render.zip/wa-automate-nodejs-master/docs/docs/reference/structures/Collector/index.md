# structures/Collector

## Index

### Classes

- [Collection](/reference/structures/Collector/classes/Collection.md)
- [Collector](/reference/structures/Collector/classes/Collector.md)

### Interfaces

- [AwaitMessagesOptions](/reference/structures/Collector/interfaces/AwaitMessagesOptions.md)
- [CollectorOptions](/reference/structures/Collector/interfaces/CollectorOptions.md)

### Type Aliases

- [CollectorFilter](/reference/structures/Collector/type-aliases/CollectorFilter.md)
