# structures/preProcessors

## Index

### Enumerations

- [PREPROCESSORS](/reference/structures/preProcessors/enumerations/PREPROCESSORS.md)

### Type Aliases

- [MPConfigType](/reference/structures/preProcessors/type-aliases/MPConfigType.md)
- [MessagePreProcessor](/reference/structures/preProcessors/type-aliases/MessagePreProcessor.md)

### Variables

- [MessagePreprocessors](/reference/structures/preProcessors/variables/MessagePreprocessors.md)
