# Type Alias: MPConfigType

> **MPConfigType**: [`PREPROCESSORS`](/reference/structures/preProcessors/enumerations/PREPROCESSORS.md) \| [`MessagePreProcessor`](/reference/structures/preProcessors/type-aliases/MessagePreProcessor.md) \| ([`PREPROCESSORS`](/reference/structures/preProcessors/enumerations/PREPROCESSORS.md) \| [`MessagePreProcessor`](/reference/structures/preProcessors/type-aliases/MessagePreProcessor.md))[]

The actual type for [config.messagePreprocessor](/docs/api/interfaces/api_model_config.ConfigObject#messagepreprocessor)
