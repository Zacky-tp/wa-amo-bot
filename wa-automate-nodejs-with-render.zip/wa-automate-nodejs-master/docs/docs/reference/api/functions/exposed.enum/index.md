# api/functions/exposed.enum

## Index

### Enumerations

- [ExposedFn](/reference/api/functions/exposed.enum/enumerations/ExposedFn.md)
