# Enumeration: ExposedFn

## Enumeration Members

### OnAnyMessage

> **OnAnyMessage**: `"onAnyMessage"`

***

### OnMessage

> **OnMessage**: `"onMessage"`

***

### onAck

> **onAck**: `"onAck"`

***

### onParticipantsChanged

> **onParticipantsChanged**: `"onParticipantsChanged"`

***

### onStateChanged

> **onStateChanged**: `"onStateChanged"`
