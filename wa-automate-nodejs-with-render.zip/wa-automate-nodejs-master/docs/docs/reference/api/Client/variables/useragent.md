# Variable: useragent

> `const` **useragent**: `string`
