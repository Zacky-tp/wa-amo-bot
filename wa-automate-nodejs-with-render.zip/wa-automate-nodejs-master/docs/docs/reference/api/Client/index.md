# api/Client

## Index

### Enumerations

- [namespace](/reference/api/Client/enumerations/namespace.md)

### Classes

- [Client](/reference/api/Client/classes/Client.md)

### Variables

- [useragent](/reference/api/Client/variables/useragent.md)
