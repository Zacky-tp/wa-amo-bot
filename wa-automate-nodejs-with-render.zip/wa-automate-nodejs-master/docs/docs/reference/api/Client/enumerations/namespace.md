# Enumeration: namespace

## Enumeration Members

### Chat

> **Chat**: `"Chat"`

***

### Contact

> **Contact**: `"Contact"`

***

### GroupMetadata

> **GroupMetadata**: `"GroupMetadata"`

***

### Msg

> **Msg**: `"Msg"`
