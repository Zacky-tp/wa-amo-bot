# api/model/call

## Index

### Enumerations

- [CallState](/reference/api/model/call/enumerations/CallState.md)

### Interfaces

- [Call](/reference/api/model/call/interfaces/Call.md)
