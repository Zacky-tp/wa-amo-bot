# Enumeration: QRQuality

The set values of quality you can set for the quality of the qr code output. Ten being the highest quality.

## Enumeration Members

### EIGHT

> **EIGHT**: `0.8`

***

### FIVE

> **FIVE**: `0.5`

***

### FOUR

> **FOUR**: `0.4`

***

### NINE

> **NINE**: `0.9`

***

### ONE

> **ONE**: `0.1`

***

### SEVEN

> **SEVEN**: `0.7`

***

### SIX

> **SIX**: `0.6`

***

### TEN

> **TEN**: `1`

***

### THREE

> **THREE**: `0.3`

***

### TWO

> **TWO**: `0.2`
