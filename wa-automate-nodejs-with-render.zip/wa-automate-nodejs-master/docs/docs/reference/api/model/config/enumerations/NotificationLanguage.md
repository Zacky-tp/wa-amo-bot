# Enumeration: NotificationLanguage

The available languages for the host security notification

## Enumeration Members

### DEDE

> **DEDE**: `"de-de"`

***

### ENGB

> **ENGB**: `"en-gb"`

***

### ES

> **ES**: `"es"`

***

### IDID

> **IDID**: `"id-id"`

***

### ITIT

> **ITIT**: `"it-it"`

***

### NLNL

> **NLNL**: `"nl-nl"`

***

### PTBR

> **PTBR**: `"pt-br"`
