# Enumeration: LicenseType

## Enumeration Members

### B2B\_RESTRICTED\_VOLUME\_LICENSE

> **B2B\_RESTRICTED\_VOLUME\_LICENSE**: `"B2B_RESTRICTED_VOLUME_LICENSE"`

***

### CUSTOM

> **CUSTOM**: `"CUSTOM"`

***

### IMAGE\_STORY

> **IMAGE\_STORY**: `"Image Story License Key"`

***

### INSIDER

> **INSIDER**: `"Insiders Program"`

***

### NONE

> **NONE**: `"NONE"`

***

### PREMIUM

> **PREMIUM**: `"Premium License Key"`

***

### TEXT\_STORY

> **TEXT\_STORY**: `"Text Story License Key"`

***

### VIDEO\_STORY

> **VIDEO\_STORY**: `"Video Story License Key"`
