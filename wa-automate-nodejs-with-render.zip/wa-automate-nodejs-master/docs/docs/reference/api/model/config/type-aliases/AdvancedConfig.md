# Type Alias: AdvancedConfig

> **AdvancedConfig**: [`ConfigObject`](/reference/api/model/config/interfaces/ConfigObject.md) & `object`

## Type declaration

### licenseKey

> **licenseKey**: `LicenseKeyConfig`
