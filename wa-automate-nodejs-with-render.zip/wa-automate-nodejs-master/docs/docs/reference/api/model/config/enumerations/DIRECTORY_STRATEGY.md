# Enumeration: DIRECTORY\_STRATEGY

## Enumeration Members

### CHAT

> **CHAT**: `"CHAT"`

E.g `/447123456789/`

***

### CHAT\_DATE

> **CHAT\_DATE**: `"CHAT_DATE"`

E.g `/447123456789/2021-08-16/`

***

### DATE

> **DATE**: `"DATE"`

E.g `/2021-08-16/`

***

### DATE\_CHAT

> **DATE\_CHAT**: `"DATE_CHAT"`

E.g `/2021-08-16/447123456789/`
