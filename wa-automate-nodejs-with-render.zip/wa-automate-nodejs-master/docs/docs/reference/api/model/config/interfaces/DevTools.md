# Interface: DevTools

## Properties

### pass

> **pass**: `string`

Password for devtools

***

### user

> **user**: `string`

Username for devtools
