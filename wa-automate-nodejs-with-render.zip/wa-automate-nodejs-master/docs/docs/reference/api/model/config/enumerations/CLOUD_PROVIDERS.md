# Enumeration: CLOUD\_PROVIDERS

## Enumeration Members

### AWS

> **AWS**: `"AWS"`

***

### CONTABO

> **CONTABO**: `"CONTABO"`

***

### DO

> **DO**: `"DO"`

***

### GCP

> **GCP**: `"GCP"`

***

### MINIO

> **MINIO**: `"MINIO"`

***

### WASABI

> **WASABI**: `"WASABI"`
