# Enumeration: QRFormat

The different types of qr code output.

## Enumeration Members

### JPEG

> **JPEG**: `"jpeg"`

***

### PNG

> **PNG**: `"png"`

***

### WEBM

> **WEBM**: `"webm"`
