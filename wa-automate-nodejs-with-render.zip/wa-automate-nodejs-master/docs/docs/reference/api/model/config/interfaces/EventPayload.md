# Interface: EventPayload

## Indexable

 \[`k`: `string`\]: `any`

## Properties

### data

> **data**: `any`

***

### event

> **event**: [`SimpleListener`](/reference/api/model/events/enumerations/SimpleListener.md)

***

### id

> **id**: `string`

***

### sessionId

> **sessionId**: `string`

***

### ts

> **ts**: `number`
