# Interface: SessionData

## Properties

### WABrowserId?

> `optional` **WABrowserId**: `string`

***

### WASecretBundle?

> `optional` **WASecretBundle**: `string`

***

### WAToken1?

> `optional` **WAToken1**: `string`

***

### WAToken2?

> `optional` **WAToken2**: `string`
