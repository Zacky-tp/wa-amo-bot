# Type Alias: ChatServer

> **ChatServer**: `"c.us"`

The suffix used to identify a non-group chat id
