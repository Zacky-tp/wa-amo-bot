# Type Alias: NonSerializedId

> **NonSerializedId**: `object`

## Type declaration

### \_serialized

> **\_serialized**: [`ContactId`](/reference/api/model/aliases/type-aliases/ContactId.md)

### server

> **server**: [`WaServers`](/reference/api/model/aliases/type-aliases/WaServers.md)

### user

> **user**: [`AccountNumber`](/reference/api/model/aliases/type-aliases/AccountNumber.md)
