# Type Alias: GroupChatServer

> **GroupChatServer**: `"g.us"`

The suffix used to identify a group chat id
