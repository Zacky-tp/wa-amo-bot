# Type Alias: GetURL

> **GetURL**: `Brand`\<`string`, `"GetURL"`\>

A URL of a file used with a GET request
