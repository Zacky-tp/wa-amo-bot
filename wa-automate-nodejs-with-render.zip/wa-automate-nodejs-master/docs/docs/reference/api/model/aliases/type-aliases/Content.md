# Type Alias: Content

> **Content**: `Brand`\<`string`, `"Content"`\>

This is a generic type alias for the content of a message

Example:

`"hello!"`
