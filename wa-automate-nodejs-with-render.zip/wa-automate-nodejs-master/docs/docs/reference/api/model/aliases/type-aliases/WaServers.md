# Type Alias: WaServers

> **WaServers**: [`ChatServer`](/reference/api/model/aliases/type-aliases/ChatServer.md) \| [`GroupChatServer`](/reference/api/model/aliases/type-aliases/GroupChatServer.md)

A type alias for all available "servers"
