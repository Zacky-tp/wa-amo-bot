# api/model/aliases

## Index

### Type Aliases

- [AccountNumber](/reference/api/model/aliases/type-aliases/AccountNumber.md)
- [AdvancedFile](/reference/api/model/aliases/type-aliases/AdvancedFile.md)
- [Base64](/reference/api/model/aliases/type-aliases/Base64.md)
- [ChatId](/reference/api/model/aliases/type-aliases/ChatId.md)
- [ChatServer](/reference/api/model/aliases/type-aliases/ChatServer.md)
- [ContactId](/reference/api/model/aliases/type-aliases/ContactId.md)
- [Content](/reference/api/model/aliases/type-aliases/Content.md)
- [CountryCode](/reference/api/model/aliases/type-aliases/CountryCode.md)
- [DataURL](/reference/api/model/aliases/type-aliases/DataURL.md)
- [FilePath](/reference/api/model/aliases/type-aliases/FilePath.md)
- [GetURL](/reference/api/model/aliases/type-aliases/GetURL.md)
- [GroupChatId](/reference/api/model/aliases/type-aliases/GroupChatId.md)
- [GroupChatServer](/reference/api/model/aliases/type-aliases/GroupChatServer.md)
- [GroupId](/reference/api/model/aliases/type-aliases/GroupId.md)
- [MessageId](/reference/api/model/aliases/type-aliases/MessageId.md)
- [NonSerializedId](/reference/api/model/aliases/type-aliases/NonSerializedId.md)
- [WaServers](/reference/api/model/aliases/type-aliases/WaServers.md)
