# Type Alias: AdvancedFile

> **AdvancedFile**: [`DataURL`](/reference/api/model/aliases/type-aliases/DataURL.md) \| [`FilePath`](/reference/api/model/aliases/type-aliases/FilePath.md) \| [`GetURL`](/reference/api/model/aliases/type-aliases/GetURL.md)

Some file based actions in open-wa are powerful enough to take a dataurl, url or filepath
