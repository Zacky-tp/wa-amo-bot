# Type Alias: FilePath

> **FilePath**: `Brand`\<`string`, `"FilePath"`\>

The relative or absolute path of a file

Learn more here: https://www.w3schools.com/html/html_filepaths.asp
