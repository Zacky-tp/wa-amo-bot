# Interface: LocationButtonBody

## Properties

### caption

> **caption**: `string`

***

### lat

> **lat**: `number`

***

### lng

> **lng**: `number`
