# Interface: Button

## Properties

### id

> **id**: `string`

***

### text

> **text**: `string`
