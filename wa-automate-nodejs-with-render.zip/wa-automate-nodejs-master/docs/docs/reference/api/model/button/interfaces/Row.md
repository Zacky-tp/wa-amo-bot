# Interface: Row

## Properties

### description

> **description**: `string`

***

### rowId

> **rowId**: `string`

***

### title

> **title**: `string`
