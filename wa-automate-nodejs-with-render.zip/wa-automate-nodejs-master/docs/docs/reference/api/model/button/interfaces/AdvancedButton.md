# Interface: AdvancedButton

## Properties

### id?

> `optional` **id**: `string`

***

### number?

> `optional` **number**: `string`

***

### text

> **text**: `string`

***

### url?

> `optional` **url**: `string`
