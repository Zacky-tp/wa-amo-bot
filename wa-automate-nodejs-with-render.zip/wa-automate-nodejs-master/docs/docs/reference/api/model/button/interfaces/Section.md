# Interface: Section

## Properties

### rows

> **rows**: [`Row`](/reference/api/model/button/interfaces/Row.md)[]

***

### title

> **title**: `string`
