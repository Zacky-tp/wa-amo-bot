# Variable: defaultProcessOptions

> `const` **defaultProcessOptions**: [`Mp4StickerConversionProcessOptions`](/reference/api/model/media/type-aliases/Mp4StickerConversionProcessOptions.md)
