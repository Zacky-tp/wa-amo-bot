# api/model/media

## Index

### Type Aliases

- [Mp4StickerConversionProcessOptions](/reference/api/model/media/type-aliases/Mp4StickerConversionProcessOptions.md)
- [StickerMetadata](/reference/api/model/media/type-aliases/StickerMetadata.md)

### Variables

- [defaultProcessOptions](/reference/api/model/media/variables/defaultProcessOptions.md)
