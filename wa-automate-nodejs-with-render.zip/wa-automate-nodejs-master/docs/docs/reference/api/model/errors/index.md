# api/model/errors

## Index

### Enumerations

- [AddParticipantErrorStatusCode](/reference/api/model/errors/enumerations/AddParticipantErrorStatusCode.md)
- [ERROR\_NAME](/reference/api/model/errors/enumerations/ERROR_NAME.md)

### Classes

- [AddParticipantError](/reference/api/model/errors/classes/AddParticipantError.md)
- [CustomError](/reference/api/model/errors/classes/CustomError.md)
- [PageEvaluationTimeout](/reference/api/model/errors/classes/PageEvaluationTimeout.md)
- [SessionExpiredError](/reference/api/model/errors/classes/SessionExpiredError.md)
