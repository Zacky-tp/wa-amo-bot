# Interface: QuoteMap

## Indexable

 \[`messageId`: `string`\]: `object`
