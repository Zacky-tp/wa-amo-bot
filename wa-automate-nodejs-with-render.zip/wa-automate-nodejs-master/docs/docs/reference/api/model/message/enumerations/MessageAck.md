# Enumeration: MessageAck

Message ACK

## Enumeration Members

### ACK\_DEVICE

> **ACK\_DEVICE**: `2`

***

### ACK\_ERROR

> **ACK\_ERROR**: `-1`

***

### ACK\_PENDING

> **ACK\_PENDING**: `0`

***

### ACK\_PLAYED

> **ACK\_PLAYED**: `4`

***

### ACK\_READ

> **ACK\_READ**: `3`

***

### ACK\_SERVER

> **ACK\_SERVER**: `1`
