# Type Alias: MessagePinDuration

> **MessagePinDuration**: `"FifteenSeconds"` \| `"FiveSeconds"` \| `"OneDay"` \| `"OneMinute"` \| `"SevenDays"` \| `"ThirtyDays"`
