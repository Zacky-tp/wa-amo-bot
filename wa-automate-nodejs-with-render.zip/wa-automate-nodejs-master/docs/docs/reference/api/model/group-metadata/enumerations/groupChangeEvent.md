# Enumeration: groupChangeEvent

## Enumeration Members

### add

> **add**: `"add"`

***

### remove

> **remove**: `"remove"`
