# Interface: NewCommunityGroup

Used when creating a new community with.

## Properties

### ephemeralDuration?

> `optional` **ephemeralDuration**: `number`

***

### icon?

> `optional` **icon**: [`DataURL`](/reference/api/model/aliases/type-aliases/DataURL.md)

***

### subject

> **subject**: `string`
