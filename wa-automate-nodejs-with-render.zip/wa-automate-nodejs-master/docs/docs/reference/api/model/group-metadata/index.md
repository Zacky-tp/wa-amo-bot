# api/model/group-metadata

## Index

### Enumerations

- [GroupNotificationTypes](/reference/api/model/group-metadata/enumerations/GroupNotificationTypes.md)
- [groupChangeEvent](/reference/api/model/group-metadata/enumerations/groupChangeEvent.md)

### Interfaces

- [GenericGroupChangeEvent](/reference/api/model/group-metadata/interfaces/GenericGroupChangeEvent.md)
- [GroupMetadata](/reference/api/model/group-metadata/interfaces/GroupMetadata.md)
- [NewCommunityGroup](/reference/api/model/group-metadata/interfaces/NewCommunityGroup.md)
- [Participant](/reference/api/model/group-metadata/interfaces/Participant.md)
- [ParticipantChangedEventModel](/reference/api/model/group-metadata/interfaces/ParticipantChangedEventModel.md)
