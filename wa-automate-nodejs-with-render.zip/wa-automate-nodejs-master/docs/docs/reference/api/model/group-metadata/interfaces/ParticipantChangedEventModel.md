# Interface: ParticipantChangedEventModel

## Properties

### action

> **action**: [`groupChangeEvent`](/reference/api/model/group-metadata/enumerations/groupChangeEvent.md)

***

### by

> **by**: [`ContactId`](/reference/api/model/aliases/type-aliases/ContactId.md)

***

### chat

> **chat**: [`ChatId`](/reference/api/model/aliases/type-aliases/ChatId.md)

***

### who

> **who**: [`ContactId`](/reference/api/model/aliases/type-aliases/ContactId.md)[]
