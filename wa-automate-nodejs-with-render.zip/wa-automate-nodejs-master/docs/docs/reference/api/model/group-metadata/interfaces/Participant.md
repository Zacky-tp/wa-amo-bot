# Interface: Participant

## Properties

### contact

> **contact**: [`Contact`](/reference/api/model/contact/interfaces/Contact.md)

***

### id

> **id**: [`NonSerializedId`](/reference/api/model/aliases/type-aliases/NonSerializedId.md)

***

### isAdmin

> **isAdmin**: `boolean`

***

### isSuperAdmin

> **isSuperAdmin**: `boolean`
