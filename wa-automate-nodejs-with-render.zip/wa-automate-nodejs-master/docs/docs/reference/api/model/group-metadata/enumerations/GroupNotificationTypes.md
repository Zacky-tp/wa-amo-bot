# Enumeration: GroupNotificationTypes

Group notification types

## Enumeration Members

### ADD

> **ADD**: `"add"`

***

### ANNOUNCE

> **ANNOUNCE**: `"announce"`

***

### DESCRIPTION

> **DESCRIPTION**: `"description"`

***

### INVITE

> **INVITE**: `"invite"`

***

### LEAVE

> **LEAVE**: `"leave"`

***

### PICTURE

> **PICTURE**: `"picture"`

***

### REMOVE

> **REMOVE**: `"remove"`

***

### RESTRICT

> **RESTRICT**: `"restrict"`

***

### SUBJECT

> **SUBJECT**: `"subject"`
