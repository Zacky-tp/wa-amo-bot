# Type Alias: EasyApiResponse

> **EasyApiResponse**: `object`

## Type declaration

### response

> **response**: `any`

### success

> **success**: `boolean`
