# api/model/sessionInfo

## Index

### Interfaces

- [HealthCheck](/reference/api/model/sessionInfo/interfaces/HealthCheck.md)
- [SessionInfo](/reference/api/model/sessionInfo/interfaces/SessionInfo.md)
