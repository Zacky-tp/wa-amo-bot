# Interface: NumberCheck

## Properties

### canReceiveMessage

> **canReceiveMessage**: `boolean`

***

### id

> **id**: [`Id`](/reference/api/model/id/interfaces/Id.md)

***

### isBusiness

> **isBusiness**: `boolean`

***

### numberExists

> **numberExists**: `boolean`

***

### status

> **status**: `200` \| `404`
