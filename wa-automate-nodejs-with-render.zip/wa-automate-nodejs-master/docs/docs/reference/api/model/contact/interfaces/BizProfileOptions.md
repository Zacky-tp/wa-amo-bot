# Interface: BizProfileOptions

## Properties

### cartEnabled

> **cartEnabled**: `boolean`

***

### commerceExperience

> **commerceExperience**: `"catalog"` \| `"none"` \| `"shop"`
