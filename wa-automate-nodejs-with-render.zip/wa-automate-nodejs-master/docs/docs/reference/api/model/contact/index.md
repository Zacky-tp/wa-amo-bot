# api/model/contact

## Index

### Interfaces

- [BizCategory](/reference/api/model/contact/interfaces/BizCategory.md)
- [BizProfileOptions](/reference/api/model/contact/interfaces/BizProfileOptions.md)
- [BusinessHours](/reference/api/model/contact/interfaces/BusinessHours.md)
- [BusinessProfile](/reference/api/model/contact/interfaces/BusinessProfile.md)
- [Contact](/reference/api/model/contact/interfaces/Contact.md)
- [NumberCheck](/reference/api/model/contact/interfaces/NumberCheck.md)
