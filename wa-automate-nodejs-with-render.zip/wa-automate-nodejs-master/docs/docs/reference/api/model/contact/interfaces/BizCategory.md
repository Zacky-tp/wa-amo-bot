# Interface: BizCategory

## Properties

### id

> **id**: `string`

***

### localized\_display\_name

> **localized\_display\_name**: `string`
