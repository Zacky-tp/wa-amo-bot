# Enumeration: Status

Client status

## Enumeration Members

### AUTHENTICATING

> **AUTHENTICATING**: `1`

***

### INITIALIZING

> **INITIALIZING**: `0`

***

### READY

> **READY**: `3`
