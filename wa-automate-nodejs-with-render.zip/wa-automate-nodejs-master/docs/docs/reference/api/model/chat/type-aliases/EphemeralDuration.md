# Type Alias: EphemeralDuration

> **EphemeralDuration**: `86400` \| `604800` \| `7776000`

Ephemeral duration can be 1 day, 7 days or 90 days. The default is 1 day.
