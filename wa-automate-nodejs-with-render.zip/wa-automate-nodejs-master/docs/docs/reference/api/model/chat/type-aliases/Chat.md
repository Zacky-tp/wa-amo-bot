# Type Alias: Chat

> **Chat**: [`SingleChat`](/reference/api/model/chat/interfaces/SingleChat.md) \| [`GroupChat`](/reference/api/model/chat/interfaces/GroupChat.md)
