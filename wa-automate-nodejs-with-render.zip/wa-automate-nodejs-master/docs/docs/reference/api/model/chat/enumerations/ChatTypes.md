# Enumeration: ChatTypes

Chat types

## Enumeration Members

### GROUP

> **GROUP**: `"group"`

***

### SOLO

> **SOLO**: `"solo"`

***

### UNKNOWN

> **UNKNOWN**: `"unknown"`
