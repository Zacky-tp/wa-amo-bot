# api/model/id

## Index

### Interfaces

- [Id](/reference/api/model/id/interfaces/Id.md)
