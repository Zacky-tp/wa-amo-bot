# Interface: Id

## Properties

### \_serialized

> **\_serialized**: `string`

***

### server

> **server**: `string`

***

### user

> **user**: `string`
