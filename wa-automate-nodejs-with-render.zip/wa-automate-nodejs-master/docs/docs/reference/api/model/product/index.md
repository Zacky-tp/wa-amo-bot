# api/model/product

## Index

### Interfaces

- [CartItem](/reference/api/model/product/interfaces/CartItem.md)
- [CustomProduct](/reference/api/model/product/interfaces/CustomProduct.md)
- [Order](/reference/api/model/product/interfaces/Order.md)
- [Product](/reference/api/model/product/interfaces/Product.md)
