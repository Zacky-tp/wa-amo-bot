# api/model/label

## Index

### Interfaces

- [Label](/reference/api/model/label/interfaces/Label.md)
