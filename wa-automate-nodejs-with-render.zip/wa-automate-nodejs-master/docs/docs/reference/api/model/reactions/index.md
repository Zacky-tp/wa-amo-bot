# api/model/reactions

## Index

### Type Aliases

- [Reaction](/reference/api/model/reactions/type-aliases/Reaction.md)
- [ReactionEvent](/reference/api/model/reactions/type-aliases/ReactionEvent.md)
- [ReactionRecord](/reference/api/model/reactions/type-aliases/ReactionRecord.md)
