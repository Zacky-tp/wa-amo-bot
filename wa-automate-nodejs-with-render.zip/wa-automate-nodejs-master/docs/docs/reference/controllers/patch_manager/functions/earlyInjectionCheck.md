# Function: earlyInjectionCheck()

> **earlyInjectionCheck**(`page`): `Promise`\<(`page`) => `boolean`\>

## Parameters

• **page**: `Page`

## Returns

`Promise`\<(`page`) => `boolean`\>
