# controllers/patch\_manager

## Index

### Functions

- [earlyInjectionCheck](/reference/controllers/patch_manager/functions/earlyInjectionCheck.md)
- [getAndInjectLicense](/reference/controllers/patch_manager/functions/getAndInjectLicense.md)
