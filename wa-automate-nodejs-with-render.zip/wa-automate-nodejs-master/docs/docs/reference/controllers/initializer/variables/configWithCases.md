# Variable: configWithCases

> `const` **configWithCases**: `any`
