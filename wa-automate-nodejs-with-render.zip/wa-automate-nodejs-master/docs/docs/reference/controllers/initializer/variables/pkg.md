# Variable: pkg

> `const` **pkg**: `any`
