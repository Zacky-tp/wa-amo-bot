# Variable: screenshot

> **screenshot**: `any`
