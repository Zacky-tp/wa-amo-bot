# Function: timeout()

> **timeout**(`ms`): `Promise`\<`string`\>

## Parameters

• **ms**: `number`

## Returns

`Promise`\<`string`\>
