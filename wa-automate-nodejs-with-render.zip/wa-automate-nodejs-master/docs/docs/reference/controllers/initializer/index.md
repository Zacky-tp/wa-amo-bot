# controllers/initializer

## Index

### Variables

- [configWithCases](/reference/controllers/initializer/variables/configWithCases.md)
- [pkg](/reference/controllers/initializer/variables/pkg.md)
- [screenshot](/reference/controllers/initializer/variables/screenshot.md)

### Functions

- [create](/reference/controllers/initializer/functions/create.md)
- [timeout](/reference/controllers/initializer/functions/timeout.md)
