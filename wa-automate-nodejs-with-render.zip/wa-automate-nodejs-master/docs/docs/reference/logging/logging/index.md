# logging/logging

## Index

### Type Aliases

- [ConfigLogTransport](/reference/logging/logging/type-aliases/ConfigLogTransport.md)

### Variables

- [log](/reference/logging/logging/variables/log.md)

### Functions

- [addRotateFileLogTransport](/reference/logging/logging/functions/addRotateFileLogTransport.md)
