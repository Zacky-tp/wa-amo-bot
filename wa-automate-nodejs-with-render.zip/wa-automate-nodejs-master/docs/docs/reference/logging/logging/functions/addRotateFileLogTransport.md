# Function: addRotateFileLogTransport()

> **addRotateFileLogTransport**(`options`): `void`

## Parameters

• **options**: `any` = `{}`

## Returns

`void`
