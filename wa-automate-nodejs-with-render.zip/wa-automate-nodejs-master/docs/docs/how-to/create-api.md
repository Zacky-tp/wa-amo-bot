# Creating an API

There are multiple convinient ways to create an API.

1. Use the ready-made API via npx

Learn more here [[Easy API]]

2. Build your own API on express and just use the built in middleware

3. 