# How does this work?

wa-automate works by automating a chrome/chromium browser process, injecting some code into the web page and exposing functionality through the "Client". Think of it like a robot sitting in front of your whatsapp web and you're controlling that robot with an API or via code.
